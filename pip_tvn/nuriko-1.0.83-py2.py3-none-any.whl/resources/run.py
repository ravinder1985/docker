#!/usr/bin/env python

import os
import nose
import sys
from datetime import datetime

from nuriko.test_context import TestContext
from nuriko.test_results import TestResults

root_dir = os.getcwd()

if TestContext.init_test_config():

    TestContext.test_config['root_dir'] = root_dir
    TestContext.test_data = None
    TestContext.set_logging_config()

    match_str = r"^test_|_test\b"
    TestContext.nose_config.append("--match=%s" % match_str)
    skipped_tests = TestResults.get_skipped_tests()

    print("***** URL used for tests = " + TestContext.test_config['url'])
    print("sys.argv = " + str(sys.argv))
    print("Nose config = " + str(TestContext.nose_config))
    print("Test config = " + str(TestContext.test_config))

    start_time = datetime.now()
    TestContext.nose_config.append("--with-timer")
    result = nose.run(argv=TestContext.nose_config)

    end_time = datetime.now()
    duration = start_time - end_time

    TestResults.create_report(TestContext.test_config, root_dir, ((duration.seconds//60) % 60), skipped_tests,
                              test_data=TestContext.test_data)

else:
    print "Could not get test environment configuration. Aborting....."
    result = False

if result:
    sys.exit(0)
else:
    sys.exit(1)