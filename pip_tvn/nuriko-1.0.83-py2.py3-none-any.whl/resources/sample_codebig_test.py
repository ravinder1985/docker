__author__ = 'mdanif001c'

import json
import requests
import urllib
import urlparse
import collections
import cgi
import binascii
import hashlib
import hmac
import time
import logging
import httplib

from random import randrange


def get_base_secrets(in_consumer, token=None):

    key = ''
    if in_consumer and 'oauth_token_secret' in in_consumer:
        key += escape(consumer['oauth_token_secret'])
    key += '&'
    if token and 'oauth_token_secret' in token:
        key += escape(token['oauth_token_secret'])

    return key


def get_base_string(in_method, in_url, in_request_params):
    """
    Generates the Signature Base String.

    http://oauth.net/core/1.0/#rfc.section.A.5.1

    """
    params = in_request_params.copy()
    params.pop('oauth_signature', None)
    new_requestparams = compose_qs(params, sort=True)

    return '&'.join((
        escape(method),
        escape(url),
        escape(new_requestparams),
    ))


def escape(value):
    return urllib.quote(value, safe='~')


def compose_qs(params, sort=False, pattern='%s=%s', join='&', wrap=None):

    ENCODED_OPEN_BRACKET = escape('[')
    ENCODED_CLOSE_BRACKET = escape(']')

    pieces = []
    for key, value in params.iteritems():
        escaped_key = escape(str(key))
        if wrap:
            escaped_key = wrap + ENCODED_OPEN_BRACKET + escaped_key + ENCODED_CLOSE_BRACKET

        if isinstance(value, collections.Mapping):
            p = compose_qs(value, sort, pattern, join, escaped_key)
        #elif SortedDict.is_nonstring_iterable(value):
        #    p = join.join([pattern % (escaped_key, escape(str(v))) for v in value])
        else:
            p = pattern % (escaped_key, escape(str(value)))
        pieces.append(p)
        
    return join.join(pieces)


def url_parseqs(query):

    d = {}
    for k, v in cgi.parse_qs(query, keep_blank_values=True).iteritems():
        if len(v) == 1:
            d[k] = v[0]
        else:
            d[k] = v
    return d


def request_to_header(in_params, realm=None):

    auth_header = 'OAuth '
    if realm:
        auth_header += 'realm="%s",' % realm
    oauth_params = dict([(k, v) for k, v in in_params.iteritems() if k[:6] == 'oauth_'])
    auth_header += compose_qs(oauth_params, pattern='%s="%s"', join=',')
    return auth_header


def oauth_parse_header(header):

    if header[:6].lower() == 'oauth ':
        header = header[6:]

    params = {}
    parts = header.split(',')
    for param in parts:
        key, value = param.strip().split('=', 1)
        if key == 'realm':
            continue
        params[key] = urllib.unquote(value.strip('"'))
    
    return params


def oauth_sign_request(in_consumer, method, url, in_params, token=None, ):

    print "\n\n inparams = ", in_params
    in_params['oauth_consumer_key'] = in_consumer['oauth_token']
    in_params['oauth_nonce'] = ''.join([str(randrange(0, 9)) for i in range(10)])
    in_params['oauth_signature_method'] = 'HMAC-SHA1'
    in_params['oauth_timestamp'] = int(time.time())
    in_params['oauth_version'] = "1.0"

    hashed = hmac.new(get_base_secrets(in_consumer), get_base_string(method, url, in_params), hashlib.sha1)
    sig = binascii.b2a_base64(hashed.digest())[:-1]
    
    in_params['oauth_signature'] = sig
    
    return in_params


def oauth_init(in_url, http_method='GET', params=None, headers={}):

    OAUTH_VERSION = '1.0'
    TIMESTAMP_THRESHOLD = 300
    NONCE_LENGTH = 10
    
    if params and not isinstance(params, collections.Mapping):
        # if its not a mapping, it must be a string
        params = url_parseqs(params)
    elif not params:
        params = {}

    if 'Authorization' in headers:
        auth_header = headers['Authorization']
        # check that the authorization header is OAuth
        if auth_header.index('OAuth') > -1:
            try:
                header_params = oauth_parse_header(auth_header)
                params.update(header_params)
            except ValueError:
                raise StandardError('Unable to parse OAuth parameters from Authorization header.')

    # URL parameters
    parts = urlparse.urlparse(url)
    in_url = '%s://%s%s' % (parts.scheme, parts.netloc, parts.path)
    params.update(url_parseqs(parts.query))

    return http_method.upper(), in_url, params.copy()

requests_log = logging.getLogger("requests.packages.urllib3")
requests_log.setLevel(logging.DEBUG)
requests_log.propagate = True
httplib.HTTPConnection.debuglevel = 1

csp_account_id = "8499101410194960"
device_id = "LNPjR70g_P-QEw2T3VRxYZhSwaEVpjh"
consumer_key = "vztqhm6dbv8t8k9uwwrdyeus"
consumer_secret = "2GWJK4rS"

url = "https://secure.api.comcast.net/einstein/stg/selfhelp/account/8499101410188053"
method = "GET"
request_headers = {'Accept': "application/json"}
request_params = {'test': "qascript"}

append_name = randrange(0, 100)
expected_device_name = "csp test %s" % append_name
data = {'friendlyName': expected_device_name}

#auth_str = TestHelper.get_auth_header(method, url, consumer_key, consumer_secret, request_params)
oauth_params = [('oauth_consumer_key', consumer_key), ('oauth_signature_method', 'HMAC-SHA1'),
                ('oauth_version', '1.0')]

sig_params = sorted(oauth_params, key=lambda parameter: parameter[0])
consumer = {'oauth_token': consumer_key, 'oauth_token_secret': consumer_secret}
method, url, params = oauth_init(url, http_method=method, params=request_params, headers={})
newparams = oauth_sign_request(consumer, method, url, params)
auth_str = 'Authorization: ' + request_to_header(newparams)
security_token_array = auth_str.strip().split(":")
request_headers['Authorization'] = security_token_array[1]
#request_headers = {'Accept': 'application/json', 'Accept-Encoding': 'gzip, deflate', 'Authorization': ' OAuth oauth_nonce="7112601441",oauth_timestamp="1423558620",oauth_consumer_key="vztqhm6dbv8t8k9uwwrdyeus",oauth_signature_method="HMAC-SHA1",oauth_version="1.0",oauth_signature="RI6b%2BWeM5xGg7i%2BNWigFtwyDccM%3D"', 'User-Agent': 'python-requests/2.3.0 CPython/2.7.6 Darwin/14.1.0'}

response = requests.get(url, headers=request_headers, params=request_params)

print "\n\n response status code = ", response.status_code
print "\n\n response text = ", response.text
print "\n\n request url = ", response.request.url
print "\n\n request headers = ", response.request.headers