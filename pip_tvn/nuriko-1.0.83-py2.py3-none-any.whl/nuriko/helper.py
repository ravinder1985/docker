#!/usr/bin/env python

"""
.. module:: helper
   :synopsis: Helper class for xPlat tests

.. moduleauthor:: Mike Danifo <michael_danifo@cable.comcast.com>

"""
import sys
import time
import urllib2
import oauth
import os
import requests
import hashlib
import json
import gzip
import calendar
import unittest
import logging
import warnings
import inspect
import traceback

from urlparse import urlparse, parse_qs
from posixpath import basename
from requests.packages.urllib3.filepost import encode_multipart_formdata
from nuriko.oauth.signature_method.hmac_sha1 import OAuthSignatureMethod_HMAC_SHA1
from nuriko.test_performance import TestPerformance
from datetime import datetime
from StringIO import StringIO

from test_context import TestContext


class TestHelper():

    """Helper class for xPlat tests"""

    # Constants

    def __init__(self):
        HTTP_METHOD_GET = "GET"
        HTTP_METHOD_POST = "POST"

    @staticmethod
    def is_setup_func():

        result = False
        for line in traceback.format_stack():
            if "setUp" in line.strip() and not result:
                result = True

        return result

    # @staticmethod
    def deprecated(func):
        """This is a decorator which can be used to mark functions
        as deprecated. It will result in a warning being emmitted
        when the function is used.
        http://code.activestate.com/recipes/391367-deprecated/"""
        def new_func(*args, **kwargs):
            warnings.simplefilter('always', DeprecationWarning)  # turn off filter
            warnings.warn("Call to deprecated function {}.".format(func.__name__),
                          category=DeprecationWarning, stacklevel=2)
            warnings.simplefilter('default', DeprecationWarning)  # reset filter
            return func(*args, **kwargs)
        new_func.__name__ = func.__name__
        new_func.__doc__ = func.__doc__
        new_func.__dict__.update(func.__dict__)
        return new_func

    @staticmethod
    def get_content_type(httpobj):
        """Get Content-Type header value from response or requesrt
        :param obj: Request or Response object
        """

        if "content-type" in httpobj.headers:
            return httpobj.headers['content-type']
        elif "Content-Type" in httpobj.headers:
            return httpobj.headers['Content-Type']
        else:
            return None

    @staticmethod
    def log_request_error(error_type, error, url, method, headers, param_data):
        """Log request information when an exception occurs in calling function using TestContext logging settings

        :param error_type: Exception type
        :param error: Exception details
        :param url: URL of the request in which the exception occured
        :param method: Request method (get, post, put, etc.)
        :param headers: Request headers for the request in which the exception occured
        :param param_data: Request query parameters and values for the request in which the exception occured
        """
        TestContext.log.error("%s ERROR \n" % error_type)
        TestContext.log.error(error)
        TestContext.log.error("Request method = %s" % method)
        TestContext.log.error("Request headers = %s" % headers)
        TestContext.log.error("Request params = %s" % param_data)
        TestContext.log.error("Request url = %s" % url)

    @staticmethod
    def log_request_response(response, **kw):
        """Log request and response information using TestContext logging settings

        :param response: Response object for which to log information about
        :param kw: Dictionary of arguments and values. Currently includes:
            testid - Test ID of the calling test or request URL if none
            error - true/false - is the logging statement due to an error in the request
            param_data - dictionary of request attributes and values
            data - data payload sent along with the request
            response_text - content of the response with formatting
        """
        test_id = kw.get("testid", response.request.url)
        param_data = kw.get("param_data", None)
        request_data = kw.get("data")
        response_text = kw.get("response_text", response.text)

        response_content_type = TestHelper.get_content_type(response)
        request_content_type = TestHelper.get_content_type(response.request)

        logging_level = logging.INFO

        if kw['error']:
            logging_level = logging.ERROR
            TestContext.failed_test_ids.append(test_id)
            TestContext.log.log(logging_level, "\n\n******ERROR DETAILS\n")
        # Only print request/response details if the request comes from a test function - JIRA SSDQA-34
        elif TestContext.test_config['logging'] == "2":
            if TestHelper.is_setup_func():
                logging_level = logging.DEBUG

        TestContext.log.log(logging_level, "Request method = %s" % response.request.method)
        TestContext.log.log(logging_level, "Request headers = %s" % response.request.headers)
        TestContext.log.log(logging_level, "Request params = %s" % param_data)
        TestContext.log.log(logging_level, "Request url = %s" % response.request.url)
        TestContext.log.log(logging_level, "Request encoding = %s" % response.encoding)
        TestContext.log.log(logging_level, "Response status = %s" % response.status_code)
        if not response_content_type or ("json" not in response_content_type
                                         and "xml" not in response_content_type
                                         and "text" not in response_content_type):
            TestContext.log.log(logging_level, "Response text is binary or non-existent- %s" % response_content_type)
        else:
            TestContext.log.log(logging_level, "Response text = %s" % response_text)
        if request_content_type:
            if "form" in request_content_type:
                TestContext.log.log(logging_level, "Request data is binary, content-type is %s" % request_content_type)
        else:
            TestContext.log.log(logging_level, "Request data = %s" % request_data)
        TestContext.log.log(logging_level, "Response headers = %s" % response.headers)
        TestContext.log.log(logging_level, "Test ID %s" % test_id)
        TestContext.log.log(logging_level, "%s" % TestHelper.get_curl_from_request(response, request_data))
        TestContext.log.log(logging_level, "\n******\n")

    @staticmethod
    def is_url_xip_or_codebig(url=None):
        """Determine if URL is a XIP/CodeBig endpoint by searching for keywords xip or secure in the url

        :param url: URL to check. If no URL is passed, URL is read from TestContext
        :return: true if URL is a xip or codebig URL, false if not
        """
        if not url:
            url = TestContext.test_config['url']

        # List of strings used to identify a URL as a CodeBig or XIP URL
        match_list = ["xip", "secure", "api.comcast.net", "codebig"]
        if any(item in url for item in match_list):
            return True
        else:
            return False

    @staticmethod
    def get_curl_from_request(response, data=None):
        """Generate curl command with arguments for the request using the corresponding response object

        :param response: Response object for which to generate curl command
        :param data: Data passed with original post/put request
        :return: String representation of curl command with header and method arguments
        """
        method = response.request.method
        uri = response.request.url
        headers = ""
        for key, val in response.request.headers.iteritems():
            if key != 'Content-Length':
                headers += " -H '%s: %s' " % (key, val)

        request_content_type = TestHelper.get_content_type(response.request)
        if request_content_type:
            if data and "str" in str(type(data)) and "form-data" not in request_content_type:
                command = "curl -v -X %s -d '%s'  %s '%s'" % (method, data, headers, uri)
            else:
                command = "curl -v -X '%s' %s '%s'" % (method, headers, uri)
        else:
            command = "curl -v -X '%s' %s '%s'" % (method, headers, uri)

        return command

    @staticmethod
    def get_id(self):
        """Generate a hash based on the full test name and return first 10 characters of hash. Assumption is that this
        function is called from a TestCase object

        :return: String representation of generated test ID
        """

        testid = self.id()
        test_hash = hashlib.md5()
        test_hash.update(testid)
        return test_hash.hexdigest()[:10]

    @staticmethod
    def timestamp():
        """Generate current date and time string timestamp with second-level precision

        :return: String representation of generated timestamp
        """
        return datetime.now().strftime("%Y.%m.%d-%H.%M.%S")

    @staticmethod
    @deprecated
    def verify_response(self, status, response, content):
        """ Verify response status code matches expected
        **Deprecated**
        :param status: Expected response status code
        :param response: Response object used for verification
        :param content:
        """
        if response.code != status:
            TestHelper.fail("Unexpected response: %s %s (%s)" % (response.code, response.msg, content))

    @staticmethod
    def request(url, method, **kw):
        """Wrapper function for sending an http request, including exception handling

        :param url: URL associated with the request
        :param method: Request method (get, post, put, delete)
        :param kw: Keyword argument dictionary. Dictionary attributes handled by this function are:
            headers: http request headers
            form: http request form data
            params: dictionary containing http request query string attributes and values
            data: data to include with http request post or put
            timeout: integer value in seconds to wait for a response from http request
            cors_enabled: boolean to indicated if Cross-Origin Resource Sharing is enabled with the request
            cors_url: URL to be used in request Origin header if cors is enabled
            auth_uid: user ID to be sent in request auth tuple for basic http authentication
            auth_pwd: user password to be sent in request auth tuple for basic http authentication
            consumer_key: consumer key to be sent in request auth header for CodeBig requests
            consumer_secret: consumer secret to be sent in request auth header for CodeBig requests

        :return: response: Response object if successful or error text if an exception occurs
        :return: response_text: Response object text, with logic to return an empty string if the response is binary
        :return: param_data: Dictionary containing http request query string attributes and values
        :return: data: Dictionary containing request josn post data, or exception object if exception occurs in request

        """
        verify = kw.get("verify", True)
        headers = kw.get("headers", {})
        form = kw.get("form", None)
        param_data = kw.get("params", None)
        content = kw.get("data", None)
        timeout = kw.get("timeout", 30)
        cors_enabled = kw.get("cors_enabled", False)
        cors_url = kw.get("cors_url", None)
        auth_uid = kw.get("auth_uid", None)
        auth_pwd = kw.get("auth_pwd", None)
        consumer_key = kw.get("consumer_key", TestContext.test_config['consumer_key']).encode('ascii', 'ignore')
        consumer_secret = kw.get("consumer_secret",
                                 TestContext.test_config['consumer_secret']).encode('ascii', 'ignore')
        oauth2_token = kw.get("oauth2_token", TestContext.test_config['oauth2_token'])

        if cors_enabled:
            headers['Origin'] = cors_url
            headers['Access-Control-Allow-Origin'] = "*"

        if form:
            (content, form_headers) = encode_multipart_formdata(form)
            headers['Content-Type'] = form_headers

        if not headers:
            headers['User-Agent'] = "Comcast-xplat-test/0.1"
            headers['Accept'] = '*/*'

        headers['Accept-Encoding'] = 'gzip, deflate'

        if not kw.get("nooauth") and oauth2_token:
            headers['Authorization'] = "Bearer " + oauth2_token

        elif TestHelper.is_url_xip_or_codebig(url=url):
            if not kw.get("nooauth") or (consumer_key and consumer_secret):
                auth_str = TestHelper.get_auth_header(method, url, consumer_key, consumer_secret, param_data)
                security_token_array = auth_str.strip().split(":")
                headers['Authorization'] = security_token_array[1]

        try:
            if auth_uid and auth_pwd:
                start = time.time()
                response = requests.request(method, url, timeout=timeout, data=content, headers=headers,
                                            params=param_data, stream=True, auth=(auth_uid, auth_pwd), verify=verify)
                response.content
                stop = time.time()
                if TestContext.test_config['performance']:
                    TestHelper.calculate_and_log_performance(start,stop,url,method,param_data)
            else:
                start = time.time()
                response = requests.request(method, url, timeout=timeout, data=content, headers=headers,
                                            params=param_data, stream=True, verify=verify)
                response.content
                stop = time.time()
                if TestContext.test_config['performance']:
                    TestHelper.calculate_and_log_performance(start,stop,url,method,param_data)

            response_text = response.text
            response_content_type = TestHelper.get_content_type(response)

            # In certain cases, we don't want to print out the response text
            if not response_text:
                response_text = ""
            elif "content-disposition" in response.headers:
                if "attachment" in response.headers['content-disposition']:
                    # Set the response content to an empty string when the response is a file
                    response_text = ""
            elif "json" in response_content_type and method != "HEAD" and response_text != "":
                if "EBIF" in response.text:
                    response_text = response.text
                elif response.json():
                    response_text = json.dumps(response.json(), indent=4)
            elif "image" in response.headers['content-type']:
                response_text = ""

            '''data = None
            if any("Accept" in item for item in response.request.headers.keys()):
                if "xml" in response.request.headers['Accept'] or "json" in response.request.headers['Accept'] \
                        or "ebif" in response.request.headers['Accept']:
                    data = content'''

        except requests.exceptions.Timeout, te:
            TestHelper.log_request_error("Timeout", str(te), url, method, headers, param_data)
            response = "critical_error"
            response_text = ""

        except requests.exceptions.ConnectionError, ce:
            TestHelper.log_request_error("Connection", str(ce), url, method, headers, param_data)
            response = "critical_error"
            response_text = ""

        except urllib2.HTTPError, e:
            TestHelper.log_request_error("HTTP", str(e), url, method, headers, param_data)
            response = "critical_error"
            response_text = ""

        except Exception, e:
            if response:
                print "\n\n response headers = %s" % response.headers
            else:
                response = "critical_error"
            TestHelper.log_request_error("Unknown error", str(e), url, method, headers, param_data)

            response_text = ""

        return response, response_text, param_data, content

    @staticmethod
    def request_and_verify(cls, url, method, retries=2, **kw):

        status = kw.get("status", None)
        if not status:
            raise Exception("status must be provided")

        is_list = True if hasattr(status, "__getitem__") else False

        for i in range(retries + 1):
            response, response_text, param_data, data = TestHelper.request(url, method, **kw)
            error = None
            if response == "critical_error":
                error = response
            elif is_list:
                if response.status_code not in status:
                    error = "status_code"
            else:
                if response.status_code != status:
                    error = "status_code"

            if not error:
                break
            time.sleep(TestHelper.__get_retry_after(response))

        if isinstance(cls, unittest.TestCase):
            testid = TestHelper.get_id(cls)
        else:
            testid = None

        if error == "critical_error":
            cls.fail("Critical error")
        elif error == "status_code":
            TestHelper.log_request_response(response, response_text=response_text, param_data=param_data,
                                            data=data, error=True, url=url, testid=testid)
            cls.fail("Expected status %s Actual status %s" % (status, response.status_code))
        else:
            TestHelper.log_request_response(response, response_text=response_text, param_data=param_data, data=data,
                                            error=False, url=url, testid=testid)

        return response, response_text

    @staticmethod
    def __get_retry_after(response, default=1):
        if isinstance(response, basestring):
            retry_after = 5
        else:
            retry_after = response.headers.get("retry-after", None)

        if retry_after is not None:
            try:
                return int(retry_after)
            except ValueError:
                pass
        return default

    @staticmethod
    def __get_or_init_headers(kw):
        headers = kw.get("headers", None)
        if not headers:
            headers = {}
            kw["headers"] = headers
        return headers

    @staticmethod
    def generate_oauth_header(oauth_token, oauth_token_secret, url, method='GET'):
        oauth_consumer = {'oauth_token': oauth_token, 'oauth_token_secret': oauth_token_secret}
        oauth_request = oauth.OAuthRequest(url, method)
        oauth_request.sign_request(OAuthSignatureMethod_HMAC_SHA1, oauth_consumer)
        return oauth_request.to_header()

    @staticmethod
    def get_auth_header(method, url, consumer_key, consumer_secret, param=None):
        oauth_params = [('oauth_consumer_key', consumer_key), ('oauth_signature_method', 'HMAC-SHA1'),
                        ('oauth_version', '1.0')]

        sig_params = sorted(oauth_params, key=lambda parameter: parameter[0])
        consumer = {'oauth_token': consumer_key, 'oauth_token_secret': consumer_secret}
        request = oauth.OAuthRequest(url, http_method=method, params=param, headers={})
        request.sign_request(OAuthSignatureMethod_HMAC_SHA1, consumer)
        return 'Authorization: ' + request.to_header()

    @staticmethod
    def split_file(file_name, num_chunks):
        """ Split a file, save chunks to separate files, and return array of file names """

        myfile = open(file_name, 'rb')
        base_name = (os.path.split(file_name))[1]
        myfile_size = os.path.getsize(file_name)
        chunksize = int(float(myfile_size) / float(num_chunks))
        chunksz = chunksize
        total_bytes = 0
        postfix = ''
        new_files = []

        for a in range(num_chunks):
            chunkfilename = base_name + '-' + str(a + 1) + postfix

            # if reading the last section, calculate correct
            # chunk size.
            if a == num_chunks - 1:
                chunksz = myfile_size - total_bytes

            try:
                data = myfile.read(chunksz)
                total_bytes += len(data)
                chunkf = file(chunkfilename, 'wb')
                chunkf.write(data)
                chunkf.close()
                new_files.append(chunkfilename)
            except (OSError, IOError), e:
                print e
                continue
            except EOFError, e:
                print e
                break

        myfile.close()

        return new_files

    @staticmethod
    def get_file_size_in_bytes(infile):
        """ Returns the file size in bytes """

        return os.path.getsize(infile)

    @staticmethod
    def get_file_data_md5(indata):

        md5 = hashlib.md5()
        md5.update(indata)
        return md5.hexdigest()

    @staticmethod
    def get_file_md5(infile, block_size=128):
        """ Read a file, generate a file content md5, and return md5 """

        with open(infile, 'rb') as fh:
            m = hashlib.md5()
            while True:
                data = fh.read(block_size)
                if not data:
                    break
                m.update(data)

        return m.hexdigest()

    @staticmethod
    def get_server_from_url(url):
        parse_url = urlparse(url)
        url = '{uri.hostname}'.format(uri=parse_url)

        return url

    @staticmethod
    def get_url_base(url):
        parse_url = urlparse(url)
        url = '{uri.scheme}://{uri.netloc}/'.format(uri=parse_url)

        return url

    @staticmethod
    def get_url_and_strip_query_string(url):
        parse_url = urlparse(url)
        return parse_url.scheme + "://" + parse_url.netloc + parse_url.path

    @staticmethod
    def get_url_base_path(url):
        parse_url = urlparse(url)
        return basename(parse_url.path)

    @staticmethod
    def get_url_query_string_val(url, qs_name):
        parse_url = urlparse(url)
        return parse_qs(parse_url.query)[qs_name]

    @staticmethod
    def get_url_query_strings_as_dict(url):
        parse_url = urlparse(url)
        return parse_qs(parse_url.query)

    def gzip(self, content):
        buf = StringIO(content)
        f = gzip.GzipFile(fileobj=buf)
        data = f.read()
        return data

    @staticmethod
    def get_datetime_in_millisecs(date_time):

        return int(calendar.timegm(date_time.timetuple()) * 1000)

    @staticmethod
    def calculate_and_log_performance(start, stop, url, method, param_data):
        roundtrip = stop - start
        roundtrip = str(round(roundtrip,5))
        if not TestHelper.is_setup_func():
            TestPerformance.log_performance(url, method, roundtrip, param_data)

    @classmethod
    def get_oauth_creds(cls, url, username, password):
        login_url = "%s/xip/login" % url
        data = {'username': username,
                'password': password,
                'deviceId': 'device_id',
                'deviceName': 'deviceName',
                'deviceType': 'deviceType',
                'appId': 'appId'}
        if TestContext.test_config.has_key("scope"):
            data["scope"] = TestContext.test_config["scope"]
        put_headers = {"Content-Type": 'application/x-www-form-urlencoded'}
        try:
            response = requests.post(login_url, data=data, headers=put_headers)
            if response.status_code != 200:
                print "\n Problem getting oauth1 token. \nResponse code = %s \n Response text = %s" % (
                    response.status_code, response.text)
                sys.exit(1)

        except urllib2.HTTPError, e:
            response = e
            print "\n POST %s - expected consumer key and secret - received %s" % (login_url, response.text)
            sys.exit(1)

        except requests.ConnectionError, e:
            print "\n Problem getting oauth1 token. Request url = %s \n %s" % (login_url, e)
            sys.exit(1)

        obj = response.json()
        return obj['consumerKey'], obj['consumerSecret']

    @classmethod
    def get_oauth2_creds(cls, username, password, client_id, client_secret, cima_url):
        login_url = cima_url
        post_data = {'client_id': client_id,
                     'client_secret': client_secret,
                     'grant_type': "password",
                     'username': username,
                     'password': password}
        put_headers = {"Content-Type": 'application/x-www-form-urlencoded', 'Accept': "application/json"}
        try:
            response = requests.post(login_url, data=post_data, headers=put_headers)
            if response.status_code != 200:
                print "\n Problem getting oauth2 token. \nResponse code = %s \n Response text = %s" % (
                    response.status_code, response.text)
                sys.exit(1)

        except urllib2.HTTPError, e:
            print "\n Problem getting oauth2 token. \n %s" % e
            sys.exit(1)

        except requests.ConnectionError, e:
            print "\n Problem getting oauth2 token. Request url = %s \n %s" % (login_url, e)
            sys.exit(1)

        obj = response.json()
        return obj['access_token']

    @classmethod
    def build_oauth_creds(cls, username=None, password=None, **kw):

        client_id = kw.get("client_id", TestContext.test_config['client_id'].encode('ascii', 'ignore'))
        client_secret = kw.get("client_secret", TestContext.test_config['client_secret'].encode('ascii', 'ignore'))
        cima_url = kw.get("cima_url", TestContext.test_config['cima_url'])
        url = kw.get("url", TestContext.test_config['url'])
        oauth_version = int(kw.get("oauth_version", TestContext.test_config['oauth_version']))
        refresh_token = kw.get("refresh_token", TestContext.test_config['refresh_token'])

        if username is None and password is None:
            username = TestContext.test_config['username']
            password = TestContext.test_config['password']

        if cls.is_url_xip_or_codebig(url=url):
            if oauth_version == 2:
                if refresh_token:
                    auth_token = cls.build_oauth2_from_refresh(client_id, client_secret, cima_url, refresh_token)
                    TestContext.test_config['oauth2_token'] = auth_token
                else:
                    auth_token = cls.get_oauth2_creds(username, password, client_id, client_secret, cima_url)
                    TestContext.test_config['oauth2_token'] = auth_token
                return auth_token
            else:
                key, secret = cls.get_oauth_creds(url, username, password)
                TestContext.test_config['consumer_key'] = key
                TestContext.test_config['consumer_secret'] = secret

    @classmethod
    def build_oauth2_from_refresh(cls, client_id, client_secret, cima_url, refresh_token):
        params = {'grant_type':'refresh_token', 'refresh_token':refresh_token}
        headers = {'Content-Type':'application/x-www-form-urlencoded'}
        response, response_text, __, ___ = cls.request(cima_url, 'POST', auth_uid=client_id, auth_pwd=client_secret, data=params, headers=headers)
        if response.status_code != 200:
            print "\n Problem getting oauth2 token. \nResponse code = %s \n Response text = %s" % (
                response.status_code, response.text)
            sys.exit(1)

        obj = json.loads(response_text)

        return obj['access_token']
