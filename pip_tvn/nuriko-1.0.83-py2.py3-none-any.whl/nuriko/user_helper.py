#!/usr/bin/env python

"""
.. module:: user_helper
   :synopsis: User and Account Helper class for xPlat tests using SSML and CRP

.. moduleauthor:: Mike Danifo <michael_danifo@cable.comcast.com>

"""
import json
import os
import requests
import sys

from helper import TestHelper


class UserHelper():

    JENKINS_URL = "http://ssd-jenkins-asha-01p.sys.comcast.net/job/NurikoUserInfoDB/ws/userinfo_db.json"

    OS_ENV_KEY_INFO = "NURIKO_USERINFO"
    OS_ENV_KEY_LOAD = "NURIKO_USERINFO_STATUS"
    os.environ[OS_ENV_KEY_LOAD] = "1" # 1 = No Attempt, 2 = Failed Attempt, 3 - Success

    SSML_URL = "https://secure.api.comcast.net/entl/profile"
    SSML_KEY = "9gpvyztuvwfzqz9xxwu785ff"
    SSML_SECRET = "YsrSKq9B"
    SSML_RH = {}
    SSML_RP = {'test': "nuriko", "nocpni": 1}
    SSML_TYPES = ["acct", "tn", "uid"]

    CRP_URL = "https://secure.api.comcast.net/crp/proxy/customerRecord"
    CRP_QA_URL = "https://secure.api.comcast.net/crp-qa/proxy/customerRecord"
    CRP_KEY = "qu936tnbd8f2ckhhqwwc545b"
    CRP_SECRET = "Jzj8mSfA"
    CRP_QA_KEY = "h6jsfezecmtt4q4awtnc9rqm"
    CRP_QA_SECRET = "nP3gB2Sw"

    @staticmethod
    def get_user_info_from_jenkins(self, userinfo_url=None):
        """Get user info from a JSON file generated on Jenkins

        :return userinfo_db: JSON representation of user info"""

        if not userinfo_url:
            url = UserHelper.JENKINS_URL

            userinfo_db = None

            try:
                r = requests.get(url, headers={'Content-Type': "application/json"}, timeout=2)
                if r.status_code == 200:
                    userinfo_db = r.json()
                else:
                    self.logger.warn("Could not get user info DB from Jenkins -- status code %s" % r.status_code)
            except Exception, e:
                self.logger.warn("Exception - Could not get user info DB from Jenkins")
        else:
            with open(userinfo_url) as userinfo:
                userinfo_db = json.load(userinfo)

        return userinfo_db

    @staticmethod
    def load_userinfodb_into_env(self, userinfo_url=None):
        """Get user info from a JSON file generated on Jenkins and load into os env"""

        userinfo_db = UserHelper.get_user_info_from_jenkins(self, userinfo_url=userinfo_url)
        if userinfo_db:
            os.environ[UserHelper.OS_ENV_KEY_LOAD] = "3"
            os.environ[UserHelper.OS_ENV_KEY_INFO] = json.dumps(userinfo_db)
        else:
            os.environ[UserHelper.OS_ENV_KEY_LOAD] = "2"
            self.logger.warn("\nCould not get user info from Jenkins")

    @staticmethod
    def get_user_info_from_ssml_api(self, **kw):

        ssml_type = kw.get("ssml_type", None)
        ssml_val = kw.get("val", None)
        skip_on_error = kw.get("skip_on_error", False)
        ssml_info = None

        url = "%s/%s/%s.json" % (UserHelper.SSML_URL, ssml_type, ssml_val)
        method = "GET"
        auth_str = TestHelper.get_auth_header(method, url, UserHelper.SSML_KEY, UserHelper.SSML_SECRET,
                                              UserHelper.SSML_RP)
        security_token_array = auth_str.strip().split(":")
        request_headers = UserHelper.SSML_RH
        request_headers['Authorization'] = security_token_array[1]
        response = requests.request(method, url, timeout=30,
                                    headers=request_headers, params=UserHelper.SSML_RP, stream=True)
        if 200 != response.status_code:
            if not skip_on_error:
                sys.exit("Could not get SSML response for url %s --- response code = %s" %
                         (url, response.status_code))
        else:
            ssml_info = response.json()['profileType']

        return ssml_info

    @staticmethod
    def get_user_info_from_ssml(self, **kw):
        """Get SSML user info

        :param kw: Keyword argument dictionary. The following dictionary attributes is required:
            ssml_type: one of uid (User ID), acct (Account ID or Account Number) or tn (Account telephone number)
            val: id value
            skip_error: true/false - don't assert on error response (used when run in batch mode)

        :return ssml_info: JSON representation of SSML user info (userType value from SSML response)"""

        ssml_type = kw.get("ssml_type", None)
        ssml_val = kw.get("val", None)
        userinfo_url = kw.get("userinfo_url", None)
        ssml_info = None

        if not ssml_type or not ssml_val:
            self.logger.error("\nid and val must be passed to this function. ** Exiting...")
        elif ssml_type not in UserHelper.SSML_TYPES:
            self.logger.error("\nid must be one of %s. ** Exiting..." % UserHelper.SSML_TYPES)
        else:
            # If no attempt as been made to load user info, load from Jenkins
            if os.environ.get(UserHelper.OS_ENV_KEY_LOAD) == "1":
                UserHelper.load_userinfodb_into_env(self, userinfo_url=userinfo_url)

            # If there was a previous failed attempt to load from Jenkins, don't try again and go to SSML
            if os.environ.get(UserHelper.OS_ENV_KEY_LOAD) == "2":
                ssml_info = UserHelper.get_user_info_from_ssml_api(self, **kw)

            # If there was a successful attempt to load from Jenkins, go here
            if os.environ.get(UserHelper.OS_ENV_KEY_LOAD) == "3":
                # Check for user info in os.env
                if os.environ.get(UserHelper.OS_ENV_KEY_INFO):
                    user_info = json.loads(os.environ.get(UserHelper.OS_ENV_KEY_INFO))
                    if ssml_val in user_info.keys():
                        ssml_info = user_info[ssml_val]
                    else:
                        self.logger.warn("\nCould not find user info for %s in os.env" % ssml_val)
                        ssml_info = UserHelper.get_user_info_from_ssml_api(self, **kw)
                elif not ssml_info:
                    self.logger.warn("\nCould not find user info for %s in os.env" % ssml_val)
                    ssml_info = UserHelper.get_user_info_from_ssml_api(self, **kw)

        return ssml_info

    @staticmethod
    def get_user_acctid(self, user, userinfo_url=None):

        user_info = UserHelper.get_user_info_from_ssml(self, ssml_type="uid", val=user, userinfo_url=userinfo_url)
        if "userType" in user_info:
            return user_info['userType']['acctId']
        else:
            return None

    @staticmethod
    def get_user_guid(self, user, userinfo_url=None):

        user_info = UserHelper.get_user_info_from_ssml(self, ssml_type="uid", val=user, userinfo_url=userinfo_url)
        if "userType" in user_info:
            return user_info['userType']['guid']
        else:
            return None

    @staticmethod
    def get_secondary_uids(self, user, userinfo_url=None):

        secondary_uids = []
        user_info = UserHelper.get_user_info_from_ssml(self, ssml_type="uid", val=user, userinfo_url=userinfo_url)
        if "userType" in user_info:
            if "assocAccts" in user_info['userType']:
                for acct in user_info['userType']['assocAccts']['assocAcct']:
                    secondary_uids.append(acct['username'])
            else:
                self.logger.error("Could not find associated accounts for user %s \n%s" %
                                  (user, json.dumps(user_info, indent=4)))

        return secondary_uids

    @staticmethod
    def get_user_email(self, user, userinfo_url=None):

        user_info = UserHelper.get_user_info_from_ssml(self, ssml_type="uid", val=user, userinfo_url=userinfo_url)
        user_email = None
        if "userType" in user_info:
            email_inbox = user_info['userType']['emailInbox']
            user_email = user + "@" + email_inbox

        return user_email

    @staticmethod
    def get_user_primary_tn(self, user, userinfo_url=None):

        primary_tn = None
        user_info = UserHelper.get_user_info_from_ssml(self, ssml_type="uid", val=user, userinfo_url=userinfo_url)

        if "tnInfo" in user_info.keys():
            tn_info = user_info['tnInfo']
            primary_tn = None
            found = False
            for tn in tn_info:
                if not found:
                    if tn['tnType'] == "ptn":
                        primary_tn = tn['tn']
                        found = True
                    elif tn['textmsg']['assignedUsers'] == user:
                        primary_tn = tn['tn']
                        found = True

            if not found:
                print("Could not find ptn or textmsg in tn SSML response for user %s \n%s" %
                                  (user, json.dumps(tn_info, indent=4)))

        else:
            self.logger.error("tnInfo not found in SSML response for user %s" % user)

        return primary_tn

    @staticmethod
    def get_customer_record(self, user):

        guid = UserHelper.get_user_guid(self, user)
        url = "%s/%s" % (UserHelper.CRP_URL, guid)
        response, _ = TestHelper.request_and_verify(self, url, "GET", status=200, headers=UserHelper.SSML_RH,
                                                    params={}, consumer_key=UserHelper.CRP_KEY,
                                                    consumer_secret=UserHelper.CRP_SECRET, oauth2_token=None)
        return response
