#!/usr/bin/env python
import os
import time
import requests
import datetime
from os.path import isfile

PERFORMANCE_FILE = "./performance.json"
HOST = "xcloud-qa.comcast.net"
TABLE_NAME = "performance"

class TestPerformance():
    @staticmethod
    def finish_log_file():
        with open(PERFORMANCE_FILE, 'a') as log_file:
            log_file.seek(0, 2)
            size = log_file.tell()
            log_file.truncate(size - 3)
            log_file.write('\n}')
            log_file.close()

    @staticmethod
    def log_performance(url, method, roundtrip, param_data):
        global session
        # write to file that will end up in the reports folder
        log_file = open(PERFORMANCE_FILE, 'a')
        ts = time.time()
        formatted_time = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d-%T.%f')
        if os.path.getsize(PERFORMANCE_FILE) == 0:
            log_file.write('{\n')
        log_file.write('\t"%s": {\n' % (formatted_time))
        log_file.write(
            '''\t\t"method":"%s",\n\t\t"url": "%s",\n\t\t"roundtrip": "%s",\n\t\t"custguid": "%s"\n\t}, \n''' % (
                method, url, roundtrip, param_data['custguid']))
        log_file.close()

    @staticmethod
    def save_json_to_database(json_file):
        if not isfile(json_file): return
        timestamp = long(time.time() * 1000)
        with open(json_file, "r") as myfile:
            content = myfile.read().replace('\n', '').replace('\t', '')
            requests.put('http://%s/ugc/stats?table=%s&date=%s' % (HOST, TABLE_NAME, timestamp),
                         headers={'Content-Type': 'application/json'}, data=content)
