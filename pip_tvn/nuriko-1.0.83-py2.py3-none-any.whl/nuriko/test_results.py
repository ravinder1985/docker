#!/usr/bin/env python

import xml.etree.ElementTree as ET
import HTML
import shutil
import os
import time
import nose
import json
import hashlib
import base64
import distutils.dir_util as du

from operator import itemgetter

from nuriko.test_context import TestContext
from nuriko.test_performance import TestPerformance

DIR_FAILURES = "failures"
HTML_RESULTS = "testresults.html"
XML_RESULTS = "nosetests.xml"


class TestResults():

    @staticmethod
    def set_failed_test_list_hash():
        """Generate a hash based on list of failed test hashes"""

        sorted_tests = sorted(TestContext.failed_test_ids)
        if sorted_tests and len(sorted_tests) > 0:
            test_string = ""
            for test in sorted_tests:
                if test:
                    test_string += test

            test_hash = hashlib.md5()
            test_hash.update(test_string)
            TestContext.failed_test_hash = test_hash.hexdigest()[:10]

            with open("failed_hash.txt", "w") as f:
                f.write("failed_test_hash=%s" % TestContext.failed_test_hash)

    @staticmethod
    def get_all_tests():
        """Use nose to return a list of all tests matching the standard matching pattern
        used in the test project run.py"""

        test_id_file = "tests.txt"
        nose_config = []
        match_str = r"^test_|_test\b"
        nose_config.append("--match=%s" % match_str)
        nose_config.append("--collect-only")
        nose_config.append("--with-id")
        nose_config.append("--id-file=%s" % test_id_file)
        nose.run(argv=nose_config)

        with open(test_id_file) as myfile:
            content = myfile.readlines()

        all_tests = []

        for (counter, curr_line) in enumerate(content):
            curr_test = {}
            if curr_line.startswith("S'") and "get_test_data" not in curr_line and \
                    ("test_" in curr_line or "_test" in curr_line) and "tests." not in curr_line:
                lines = curr_line.rstrip().split(".")
                last_two = lines[-2:]
                if len(last_two) == 2:
                    curr_test['name'] = last_two[0].lstrip("S'") + "." + last_two[1].rstrip("'")
                else:
                    curr_test['name'] = last_two[0]
                curr_test['id'] = content[counter+1].rstrip()
                all_tests.append(curr_test)

        os.remove(test_id_file)

        return all_tests

    @staticmethod
    def get_matching_tests():
        """Use nose to return a list of all tests matching the standard matching pattern and command line arguments
        passed to the test project run.py"""

        nose_config = list(TestContext.nose_config)
        # Remove multi-process nose argument when collecting matching tests
        for item in nose_config:
            if "processes" in item:
                nose_config.remove(item)

        test_id_file = "matchtests.txt"
        nose_config.append("--collect-only")
        nose_config.append("--with-id")
        nose_config.append("--id-file=%s" % test_id_file)
        nose.run(argv=nose_config)

        with open(test_id_file) as myfile:
            content = myfile.readlines()

        all_tests = []

        for (counter, curr_line) in enumerate(content):
            curr_test = {}
            if curr_line.startswith("S'") and "get_test_data" not in curr_line and \
                    ("test_" in curr_line or "_test" in curr_line) and "tests." not in curr_line:
                lines = curr_line.rstrip().split(".")
                last_two = lines[-2:]
                if len(last_two) == 1:
                    curr_test['name'] = last_two
                else:
                    curr_test['name'] = last_two[0].lstrip("S'") + "." + last_two[1].rstrip("'")
                curr_test['id'] = content[counter+1].rstrip()
                all_tests.append(curr_test)

        os.remove(test_id_file)

        return all_tests

    @staticmethod
    def get_skipped_tests():
        """Compare all tests with matching tests and return the list of tests skipped because they don't match the
        run criteria"""

        all_tests = TestResults.get_all_tests()
        all_test_names = []
        for test in all_tests:
            all_test_names.append(test['name'])

        matching_tests = TestResults.get_matching_tests()
        matching_test_names = []
        for test in matching_tests:
            matching_test_names.append(test['name'])

        skipped_tests = [x for x in all_test_names if x not in matching_test_names]
        print "ALL TESTS = ", len(all_test_names)
        print "MATCHING TESTS = ", len(matching_test_names)
        print "SKIPPED TESTS = ", len(skipped_tests)
        return sorted(skipped_tests)

    @staticmethod
    def create_report(env_config, results_dir, duration, skipped_tests=None, xml_results=None, test_data=None):

        html_header = "<HTML><HEAD><TITLE>Test Report</TITLE></HEAD><BODY>"
        html_footer = "</BODY></HTML>"

        results_dir1 = "%s/%s" % (results_dir, TestContext.test_config['report-dir'])
        results_dir_full = "%s.%s.%s" % (results_dir1, TestContext.test_config['env'], time.strftime("%Y%m%d-%H.%M.%S"))

        os.makedirs(results_dir_full)

        html_file = open(results_dir_full + "/" + HTML_RESULTS, 'w')
        html_file.write(html_header)
        html_file.write("<H3>Test Report</H3>")
        html_file.write("<a href='#test_environment'>Test Environment</a>")
        if test_data:
            html_file.write("<br><a href='#test_data'>Test Data</a>")
        html_file.write("<H3>All Tests</H3>")
        html_table = HTML.Table(header_row=["result", "duration", "test", "test class"],
                                attribs={'style': 'font-size:8pt'})

        if xml_results is None:
            xml_file = results_dir + "/" + XML_RESULTS
        else:
            xml_file = xml_results

        xml_tree = ET.parse(xml_file)
        xml_root = xml_tree.getroot()
        failure_list = []
        failure_rows = []
        success_rows = []
        skip_rows = []

        # Write main test result table
        for elem_child in xml_root:
            class_name = elem_child.attrib['classname']
            row_data = []

            if len(elem_child) > 0:
                for elem_sub_child in elem_child:
                    if elem_sub_child.tag == "failure" or elem_sub_child.tag == "error":
                        failure_details = {
                            'test_name': elem_child.attrib['name'],
                            'error_message': elem_sub_child.attrib['message'],
                            'error_details': elem_sub_child.text
                        }
                        failure_list.append(failure_details)
                        test_result = "fail"
                        cell_color = "Red"
                        name_cell = "<a href='#%s'>%s</a>" % (elem_child.attrib['name'], elem_child.attrib['name'])
                        colored_cell = HTML.TableCell(test_result, bgcolor=cell_color)
                        duration_cell = HTML.TableCell(elem_child.attrib['time'], align="right")
                        row_data.append(colored_cell)
                        #row_data.append(elem_child.attrib['time'])
                        row_data.append(duration_cell)
                        row_data.append(name_cell)
                        row_data.append(class_name)
                        failure_rows.append(row_data)
            else:
                test_result = "pass"
                cell_color = "Green"
                name_cell = elem_child.attrib['name']
                colored_cell = HTML.TableCell(test_result, bgcolor=cell_color)
                duration_cell = HTML.TableCell(elem_child.attrib['time'], align="right")
                row_data.append(colored_cell)
                #row_data.append(elem_child.attrib['time'])
                row_data.append(duration_cell)
                row_data.append(name_cell)
                row_data.append(class_name)
                success_rows.append(row_data)
            #html_table.rows.append(row_data)

        # Write skipped tests to table
        if skipped_tests:
            for test in skipped_tests:
                test_result = "skip"
                cell_color = "LightGray"
                colored_cell = HTML.TableCell(test_result, bgcolor=cell_color)
                duration_cell = HTML.TableCell("0", align="right")
                if "." in test:
                    class_name, test_name = test.split('.')
                    row_data = [colored_cell, duration_cell, test_name, class_name]
                else:
                    row_data = [colored_cell, duration_cell, test, ""]
                skip_rows.append(row_data)

        failure_rows = sorted(failure_rows, key=itemgetter(0, 1))
        success_rows = sorted(success_rows, key=itemgetter(0, 1))
        skip_rows = sorted(skip_rows, key=itemgetter(0, 1))
        html_table.rows = failure_rows + success_rows + skip_rows
        html_file.write(str(html_table))

        # Write failed test details anchors towards the bottom of the page
        for failure in failure_list:
            html_file.write("<p id='%s'>" % failure['test_name'])
            html_file.write("<H3>Test Name - %s</H3>" % failure['test_name'])
            if "error_message" in failure.keys():
                html_file.write("<p><pre>%s</p>" % failure['error_message'].encode("utf-8"))
            if "error_details" in failure.keys():
                html_file.write("<p><pre>%s</p>" % failure['error_details'].encode("utf-8"))

        # Write test environment table
        html_file.write("<br><a name='test_environment'></a>")
        html_file.write("<H3>Test Enviroment</H3>")
        html_env_table = HTML.Table()
        html_env_table.rows.append(["date/time", time.strftime("%c")])
        html_env_table.rows.append(["test execution duration", str(duration)])
        for key, val in env_config.iteritems():
            if val:
                if "password" in key:
                    html_env_table.rows.append([key, base64.b64encode(val)])
                else:
                    html_env_table.rows.append([key, val])
        html_file.write(str(html_env_table))

        if test_data:
            # Write test data table
            html_file.write("<br><a name='test_data'></a>")
            html_file.write("<H3>Test Data</H3>")
            html_file.write("<p><pre>%s</pre></p>" % json.dumps(test_data, sort_keys=True, indent=4))

        html_file.write(html_footer)
        html_file.close()

        #in try/except to address the case where the test fails in setup and the performance file never gets created
        if TestContext.test_config['performance']:
            try:
                TestPerformance.finish_log_file()
                TestPerformance.save_json_to_database('performance.json')
                shutil.copy('performance.json','%s/performance.json' % results_dir_full)
            except:
                pass

        du.copy_tree(results_dir_full, results_dir1)

        root_dir = os.getcwd()
        try:
            os.remove('%s/performance.json' % root_dir)
        except:
            pass

        TestResults.set_failed_test_list_hash()

        print "----------------------------------------------------------------------"
        print "RESULTS: %s/%s" % (TestContext.test_config['report-dir'], HTML_RESULTS)
        print "----------------------------------------------------------------------"
