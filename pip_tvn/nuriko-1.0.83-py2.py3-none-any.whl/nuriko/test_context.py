import json
import logging
import argparse
import httplib
import os
import base64
import sys


class TestContext:
    DEFAULT_TESTS = ['basic_tests']
    DEFAULT_REALM = 'PAL Security Realm'
    ENV_JSON_CONFIG = "env.json"
    ARG_JSON_CONFIG = "../resources/testargs.json"
    ARG_JSON_USERS = "../resources/testusers.json"
    CONFIG_ERROR = False
    LOG_FILE = "xplat_test.log"

    test_args = {}
    nose_args = []
    failed_test_ids = []
    failed_test_hash = ""
    root_dir = ""

    @staticmethod
    def get_user_data():
        """Get user data from test user json in reources directory

        :return: array of user json dicts
        """
        curr_path = os.path.abspath(__file__)
        curr_dir_path = os.path.dirname(curr_path)
        with open(curr_dir_path + "/" + TestContext.ARG_JSON_USERS) as json_file:
            json_data = json.load(json_file)

        return json_data['users']

    @staticmethod
    def get_nose_args():
        """Get array of possible nose arguments used in tests from json. Values in array
        are a subset of all the possible arguments that can be used in the nose framework

        :return: array of nose arguments
        """
        curr_path = os.path.abspath(__file__)
        curr_dir_path = os.path.dirname(curr_path)
        with open(curr_dir_path + "/" + TestContext.ARG_JSON_CONFIG) as json_file:
            json_data = json.load(json_file)

        return json_data['nose_args']

    @staticmethod
    def get_test_args():
        """Get array of possible test arguments with defaut values from json.
        TODO: this list of arguments should be able to be customized per test project

        :return: dictionary of test arguments and default values
        """
        curr_path = os.path.abspath(__file__)
        curr_dir_path = os.path.dirname(curr_path)
        with open(curr_dir_path + "/" + TestContext.ARG_JSON_CONFIG) as json_file:
            json_data = json.load(json_file)

        return json_data['test_args']

    @classmethod
    def parse_cmdline_args(cls, allargs, **kw):

        mock_test_args = kw.get("test_args", cls.test_args)
        mock_nose_args = kw.get("nose_args", cls.nose_args)

        parse_result = True
        # Check for empty argument list
        if not allargs:
            print "No arguments passed. Either pass --env or --url, --username, and --password"
            parse_result = False
        else:
            cls.nose_config = ['']
            cls.test_config = {}

            for key, value in mock_test_args.iteritems():
                _, argname = key.split("--")
                cls.test_config[argname] = value

            for item in allargs:
                try:
                    if item.startswith("--"):
                        (arg, val) = item.split("=", 1)
                        if arg in mock_nose_args:
                            cls.nose_config.append(item)
                        elif arg in mock_test_args.keys():
                            _, argname = arg.split("--")
                            cls.test_config[argname] = val
                        else:
                            print "parse_cmdline_args - Invalid argument " + arg
                            parse_result = False
                except ValueError:
                    print "Problem parsing command line for argument " + item + ". Command line format is --arg=val"
                    parse_result = False

        return parse_result


    @classmethod
    def check_command_line_args(cls):
        """Check command line arguments and determine if required arguments are passed
        Currently the following are the required command line arguments:
        --env or --host and --username and --password

        Check if the --where argument is passed and set the value to a subdirectory of the working directory

        :return: boolean indicating success/fail result
        """

        # prepend the current working directory to the --where argument value
        for itr, item in enumerate(cls.nose_config):
            if "where" in item:
                cls.nose_config[itr] = "--where=%s" % os.path.join(os.getcwd(), item.split("=")[1])

        error_message_base = "is not passed or value is null. Either pass --env or --url, --username, and --password"
        if cls.test_config['env'] in (None, ""):
            print "WARN: --env argument is not passed, looking for --url and --username command line arguments"
            if cls.test_config['url'] in (None, ""):
                print "ERROR: --url argument ", error_message_base
                return False
            elif cls.test_config['username'] in (None, ""):
                print "ERROR: --username argument ", error_message_base
                return False
            elif cls.test_config['password'] in (None, ""):
                if cls.user_data[cls.test_config['username']]['password'] in (None, ""):
                    print "ERROR: --password argument ", error_message_base
                    return False
                else:
                    cls.test_config['password'] = \
                        base64.b64decode(cls.user_data[cls.test_config['username']]['password'])
                    return True
            else:
                return True
        else:
            return True

    @classmethod
    def set_env_config(cls):

        # Get test environment configuration from JSON
        with open("./resources/" + cls.ENV_JSON_CONFIG) as json_data:
            data = json.load(json_data)

        env_types = data.keys()
        env_type = "env_" + cls.test_config['env']
        if env_type not in env_types:
            print "ERROR: invalid env_type " + env_type + ", must be one of " + str(data.keys())
            return False
        else:
            for key, value in data.iteritems():
                if key == env_type:
                    env_data = value

            if env_data:
                for key, value in env_data.iteritems():
                    # If env json attribute is empty or does not exist is testargs json
                    if (key not in cls.test_config.keys()) or (not cls.test_config[key]):
                        cls.test_config[key] = value
                    else:
                        print cls.test_config.keys()
                        print key, value
                        print "init_test_config - found value for argument ", key, " on command line"
                return True
            else:
                return True

    @classmethod
    def set_logging_config(cls, **kw):
        """Setup logging format and levels used based on command line parameters"""

        log_level = kw.get("log_level", cls.test_config['logging'])

        log_formatter = logging.Formatter('%(asctime)s %(message)s', '%m/%d/%Y-%I:%M:%S')
        cls.log = logging.getLogger(__name__)

        cls.test_fh = logging.FileHandler(cls.LOG_FILE, mode='a')
        cls.test_fh.setFormatter(log_formatter)

        cls.all_sh = logging.StreamHandler()
        cls.all_sh.setFormatter(log_formatter)

        if not cls.log.handlers:
            cls.nose_config.append("--with-xunit")
            cls.nose_config.append("--nocapture")
            cls.nose_config.append("--exe")
            cls.nose_config.append("-v")

            cls.requests_log = logging.getLogger("requests.packages.urllib3")

            cls.log.addHandler(cls.test_fh)
            cls.log.addHandler(cls.all_sh)
            cls.requests_log.addHandler(cls.test_fh)

            if log_level == "0":

                print "Setting logging config level 0"
                cls.log.setLevel(logging.ERROR)
                cls.requests_log.setLevel(logging.ERROR)

                cls.all_sh.setLevel(logging.ERROR)

            elif log_level == "1":

                print "Setting logging config level 1"
                cls.log.setLevel(logging.WARN)
                cls.requests_log.setLevel(logging.WARN)
                cls.all_sh.setLevel(logging.WARN)

            elif log_level == "2":

                print "Setting logging config level 2"
                cls.log.setLevel(logging.INFO)
                cls.requests_log.setLevel(logging.ERROR)
                cls.requests_log.addHandler(cls.all_sh)

            elif log_level == "3":

                print "Setting logging config level 3"
                cls.log.setLevel(logging.DEBUG)
                cls.requests_log.setLevel(logging.DEBUG)
                cls.requests_log.propagate = True
                httplib.HTTPConnection.debuglevel = 1
                cls.all_sh.setLevel(logging.DEBUG)
                cls.requests_log.addHandler(cls.all_sh)

    @classmethod
    def init_test_config(cls, arglist=None):
        """Parse command line arguments and determine which arguments will be passed on to the
        nose test framework, and which arguments will be used in the actual tests.

        This function also reads in a json file that includes test environment attributes and values.
        Values provided in the json file are overridden by their corresponding command line arguments.

        """
        # Get list of possible nose args from json
        cls.nose_args = cls.get_nose_args()
        # Get a dictionary of possible test args and default values from json
        cls.test_args = cls.get_test_args()
        # Get a dictionary of test user data
        cls.user_data = cls.get_user_data()

        # Get args and values from the command line
        parser = argparse.ArgumentParser(usage="usage: run.py [options]")
        if arglist:
            _, allargs = arglist
        else:
            _, allargs = parser.parse_known_args()

        # Parse command line and build nose and test arg:val dictionaries
        cmdline_parse_result = cls.parse_cmdline_args(allargs)

        # Check test arg:val dictionary for required attributes if parse check passes
        if cmdline_parse_result:
            cmdline_check_result = cls.check_command_line_args()
        else:
            return False

        if cmdline_check_result:
            if cls.test_config['env']:
                set_envconfig_result = cls.set_env_config()
            else:
                set_envconfig_result = True
        else:
            return False

        if set_envconfig_result:
            return True
        else:
            return False